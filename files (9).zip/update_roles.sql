-- ============================================================
-- 更新權限規則:
-- michellechang154@gmail.com = 管理員 (可讀/新增/刪除)
-- jjenchi@gmail.com          = 僅檢視 (只能讀)
-- ============================================================

-- 先刪掉舊的權限規則
drop policy if exists "select_own_records" on material_records;
drop policy if exists "insert_own_records" on material_records;
drop policy if exists "delete_own_records" on material_records;

-- 新規則1: 兩個帳號都可以讀取所有資料
create policy "select_authenticated" on material_records
  for select
  using (
    auth.jwt() ->> 'email' in (
      'michellechang154@gmail.com',
      'jjenchi@gmail.com'
    )
  );

-- 新規則2: 只有管理員可以新增
create policy "insert_admin_only" on material_records
  for insert
  with check (
    auth.jwt() ->> 'email' = 'michellechang154@gmail.com'
  );

-- 新規則3: 只有管理員可以刪除
create policy "delete_admin_only" on material_records
  for delete
  using (
    auth.jwt() ->> 'email' = 'michellechang154@gmail.com'
  );
